
module.exports = {
    testEnvironment: "jsdom",
    setupFiles: ["../scripts/setup.js"], // Add JSDOM setup
};

